#ifndef FINALPROJ_DOWNLOADFILE_H
#define FINALPROJ_DOWNLOADFILE_H

#pragma once

#include <string>
#include <sstream>


void downloadFile(const std::string & szWebSite, std::stringstream &strStream);


#endif //FINALPROJ_DOWNLOADFILE_H
