//
// Created by Mr.Late on 5/3/17.
//

#ifndef FINALPROJ_NASDAQSCOREMODEL_H
#define FINALPROJ_NASDAQSCOREMODEL_H


class NasdaqScoreModel {

};


#endif //FINALPROJ_NASDAQSCOREMODEL_H
