//
// Created by Mr.Late on 5/3/17.
//

#include "WeightedAVGScoringStrategy.h"
#include "iostream"

using namespace std;

    map<string, double>   WeightedAVGScoringStrategy::StockScoringStrategy(vector<string> &vector) {
    cout<< "WeightedAVGScoringStrategy\n";
    map<string,double> scoredMap;
//    return NULL;
    return scoredMap;
}
