//
// Created by Mr.Late on 5/4/17.
//

#ifndef FINALPROJ_FILEPATHCONST_H
#define FINALPROJ_FILEPATHCONST_H

#include <string>


 class FilePathConst{
public:

};

//static FilePathConst std::string stk_assessment_file = "NasdaqDataTest.txt";
#endif //FINALPROJ_FILEPATHCONST_H
